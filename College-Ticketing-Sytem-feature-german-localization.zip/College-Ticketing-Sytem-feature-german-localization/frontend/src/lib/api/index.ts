export {
  apiBaseUrl,
  apiClient,
  apiRequest,
  del,
  get,
  getDataSourceMode,
  isMockDataSource,
  mockLatency,
  patch,
  post,
  postForm,
  put,
  usesLiveAuth,
  usesLiveChat,
  usesLiveTickets,
  usesMockKnowledge,
  usesMockNotifications,
  type DataSourceMode,
} from './client'
export { ApiError, isApiError, toApiError, type ApiErrorCode } from './errors'
export { authApi, signOut } from './auth'
export { ticketsApi, formatFileSize } from './tickets'
export { notificationsApi } from './notifications'
export { knowledgeApi } from './knowledge'
export { usersApi, type StaffMember } from './users'
export type {
  ChatConversation,
  ChatMessage,
  ChatMode,
  Citation,
  EscalatedTicket,
  EscalateResult,
  LlmHealth,
  StreamHandlers,
  StreamResult,
} from './chat'
export { chatApi } from './chat'
export type * from './types'
